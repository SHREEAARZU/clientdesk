# Client Desk

Client management for health insurance agents: birthdays, anniversaries, renewals, follow-ups and WhatsApp messages.
Data is stored only in your phone's browser. Use Backup > Download backup regularly.

## Host free on GitHub Pages
1. Create a GitHub account and a new **public** repository named `clientdesk`.
2. Upload all files from this folder (index.html, manifest.json, sw.js, icon-192.png, icon-512.png, README.md).
3. Go to Settings > Pages. Under Branch choose `main` and folder `/ (root)`, then Save.
4. After a minute your app is live at `https://YOURNAME.github.io/clientdesk/`.

## Install on your phone
- iPhone (Safari): Share > Add to Home Screen.
- Android (Chrome): menu > Install app / Add to Home screen.

## Moving your data
Download a backup from the old link and restore it on the new link. Browser data does not carry over between addresses.
